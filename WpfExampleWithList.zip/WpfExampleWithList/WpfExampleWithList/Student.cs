﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfExampleWithList
{
    public class Student
    {
        //Data Members
        private string firstName;
        private string lastName;
        private int age;
        private string course;

        //Properties
        public string FirstName { get { return firstName; } set { firstName = value; } }
        public string LastName { get { return lastName; } set { lastName = value; } }
        public string Age { get { return Age; } set { Age = value; } }
        public string Course { get { return course; } set { course = value; } }
    }
}











